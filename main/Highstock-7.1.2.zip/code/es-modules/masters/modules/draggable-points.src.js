/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * @module highcharts/modules/draggable-points
 * @requires highcharts
 *
 * (c) 2009-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/draggable-points.src.js';
